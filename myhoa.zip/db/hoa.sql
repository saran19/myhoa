-- phpMyAdmin SQL Dump
-- version 4.5.2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Aug 26, 2016 at 09:58 AM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.5.35

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hoa`
--

-- --------------------------------------------------------

--
-- Table structure for table `hoa_account_type`
--

CREATE TABLE `hoa_account_type` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `status` int(11) NOT NULL DEFAULT '0',
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `lastr_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hoa_account_type`
--

INSERT INTO `hoa_account_type` (`id`, `name`, `image`, `status`, `created_date`, `lastr_updated`) VALUES
(1, 'Home Owners', 'assets/images/avatar_1.jpg', 0, '2016-08-05 15:59:56', '0000-00-00 00:00:00'),
(2, 'Management Company', 'assets/images/avatar_1.jpg', 0, '2016-08-05 15:59:56', '0000-00-00 00:00:00'),
(3, 'HOA Admin', 'assets/images/avatar_1.jpg', 1, '2016-08-05 15:59:56', '0000-00-00 00:00:00'),
(4, 'Vendor', 'assets/images/avatar_1.jpg', 0, '2016-08-05 15:59:56', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `hoa_community`
--

CREATE TABLE `hoa_community` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `desc` text NOT NULL,
  `code` varchar(255) NOT NULL,
  `website` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `fax` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hoa_community`
--

INSERT INTO `hoa_community` (`id`, `name`, `desc`, `code`, `website`, `phone`, `mobile`, `fax`, `status`, `created_date`, `last_updated`) VALUES
(1, 'Test Community', '', 'TE10ST', '', '', '', '', 0, '2016-08-08 13:18:24', '0000-00-00 00:00:00'),
(4, 'Ram Community', 'Test', 'RA77TY0', 'http://www.google.com', '', '', '', 0, '2016-08-08 17:59:33', '0000-00-00 00:00:00'),
(7, 'Another Test Community', 'Hi', 'AN64TY1', 'http://www.google.com', '', '', '', 0, '2016-08-08 19:06:01', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Table structure for table `hoa_form`
--

CREATE TABLE `hoa_form` (
  `id` int(11) NOT NULL,
  `form_name` varchar(255) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hoa_form`
--

INSERT INTO `hoa_form` (`id`, `form_name`, `user_id`) VALUES
(1, 'Ram', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hoa_form_data`
--

CREATE TABLE `hoa_form_data` (
  `id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `data` text NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hoa_form_data`
--

INSERT INTO `hoa_form_data` (`id`, `form_id`, `data`, `created_date`) VALUES
(1, 1, '{"Title":"Personal Info","Firstname":"Ramkumar","Lastname":"S","Email-ID":"ramkumar.izaap@gmail.com","Age":"25","PayTo":"To Camp Registration","Amount":"$5.00","TransID":"","Status":"Pending"}', '2016-08-26 13:18:40');

-- --------------------------------------------------------

--
-- Table structure for table `hoa_form_fields`
--

CREATE TABLE `hoa_form_fields` (
  `id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `field` text NOT NULL,
  `sort` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hoa_form_fields`
--

INSERT INTO `hoa_form_fields` (`id`, `form_id`, `field`, `sort`) VALUES
(6, 1, '{"form_id":"1","label":"Test Form","type":"title-field","options":",,","required":"off"}', 0),
(18, 1, '{"form_id":"1","label":"Personal Info","type":"personal-field","options":",,","required":"on"}', 1),
(19, 1, '{"form_id":"1","label":"Save Form","type":"submit-field","options":",,","required":"off"}', 3),
(21, 1, '{"form_id":"1","label":"To Camp Registration","type":"payment-field","options":",,","amount":"5.00","required":"off"}', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hoa_form_payment`
--

CREATE TABLE `hoa_form_payment` (
  `id` int(11) NOT NULL,
  `form_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pay_to` varchar(255) NOT NULL,
  `amount` varchar(255) NOT NULL,
  `trans_id` varchar(255) NOT NULL,
  `status` varchar(255) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hoa_form_payment`
--

INSERT INTO `hoa_form_payment` (`id`, `form_id`, `user_id`, `pay_to`, `amount`, `trans_id`, `status`, `created_date`) VALUES
(1, 1, 1, 'To Camp Registration', '5.00', '', 'Pending', '2016-08-26 13:18:40');

-- --------------------------------------------------------

--
-- Table structure for table `hoa_users`
--

CREATE TABLE `hoa_users` (
  `id` int(11) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `code` int(11) NOT NULL,
  `address` text NOT NULL,
  `phone` varchar(255) NOT NULL,
  `mobile` varchar(255) NOT NULL,
  `about_me` text NOT NULL,
  `usertype` int(11) NOT NULL,
  `created_date` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `last_updated` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hoa_users`
--

INSERT INTO `hoa_users` (`id`, `firstname`, `lastname`, `username`, `email`, `password`, `code`, `address`, `phone`, `mobile`, `about_me`, `usertype`, `created_date`, `last_updated`) VALUES
(1, 'Ramkumar', 'Srinivasan', 'ramkumar', 'ramkumar.izaap@gmail.com', '123456', 1, 'Chennai', '1234567890', '1234567890', 'Good Boy										', 1, '2016-08-08 13:34:50', '0000-00-00 00:00:00'),
(2, 'Ramkumars', 'Srinivasans', 'ramkumars', 'ramkumar.izaap@gmail.coms', '1234567', 1, 'Chennais', '1234567890', '1234567890', 'Good Boy										', 1, '2016-08-08 13:34:50', '0000-00-00 00:00:00');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `hoa_account_type`
--
ALTER TABLE `hoa_account_type`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hoa_community`
--
ALTER TABLE `hoa_community`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hoa_form`
--
ALTER TABLE `hoa_form`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hoa_form_data`
--
ALTER TABLE `hoa_form_data`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hoa_form_fields`
--
ALTER TABLE `hoa_form_fields`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hoa_form_payment`
--
ALTER TABLE `hoa_form_payment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hoa_users`
--
ALTER TABLE `hoa_users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `hoa_account_type`
--
ALTER TABLE `hoa_account_type`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `hoa_community`
--
ALTER TABLE `hoa_community`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `hoa_form`
--
ALTER TABLE `hoa_form`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `hoa_form_data`
--
ALTER TABLE `hoa_form_data`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `hoa_form_fields`
--
ALTER TABLE `hoa_form_fields`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `hoa_form_payment`
--
ALTER TABLE `hoa_form_payment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT for table `hoa_users`
--
ALTER TABLE `hoa_users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
