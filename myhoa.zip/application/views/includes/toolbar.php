<div class="social_toolbar">
	<ul>
		<li><a href="<?=base_url();?>">Home</a></li>
		<li><a href="#">Profile</a>
			<ul>
				<li><a href="#">Edit</a></li>
			</ul>
		</li>
		<li><a href="<?=base_url();?>community/create">Community</a></li>
		<li><a href="#">Profile</a></li>
		<li><a href="#">Profile</a></li>
	</ul>
</div>