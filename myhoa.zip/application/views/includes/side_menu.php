<div class="col-md-3">
	<ul class="main-nav">
		<li><a href="<?=base_url();?>">Home <span class="count">1</span></a></li>
		<li><a href="<?=base_url();?>invoices">Invoices</a></li>
		<li><a href="<?=base_url();?>classifieds">Classifieds</a></li>
		<li><a href="#">Events</a></li>
		<li><a href="<?=base_url();?>inbox">Inbox</a></li>
		<li><a href="<?=base_url();?>form">Dynamic Form </a></li>
	</ul>
</div>