<footer>
	<div class="col-md-7 col-sm-offset-1 pad-top-20 font-11">
		<a href="#" class="col-md-2">Terms of Service</a>
		<a href="#" class="col-md-2">Privacy Policy</a>
	</div>
	<div class="col-md-4 pull-right text-right pad-top-20 pad-right-50">
			<a id="back-to-top" back-to-top" role="button" href="#" class="top">&nbsp;</a>
	</div>
  <div class="form-group text-center font-11 login-modal-footer col-md-12">
    <p>&copy; <?=date("Y");?> Miriad Technologies,LLC. All Rights Reserved.</p>
  </div>
</footer>