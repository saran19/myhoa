<div class="container pad-top-50 inbox-page">
	<div class="row pad-top-50 ">
		<?=$this->layout->getsidemenu();?>
		<div class="col-md-8">
			<h2 class="margin-zero padd-zero">Inbox</h2><br>
		</div>
		<div class="col-md-8">
			<div class="panel with-nav-tabs panel-primary">
        <div class="panel-heading">
          <ul class="nav nav-tabs">
              <li class="active"><a href="#tab1primary" data-toggle="tab">Inbox</a></li>
              <li><a href="#tab2primary" data-toggle="tab">Compose</a></li>
          </ul>
        </div>
        <div class="panel-body">
          <div class="tab-content">
            <div class="tab-pane fade in active" id="tab1primary">Primary 1</div>
            <div class="tab-pane fade" id="tab2primary">
            	<div class="row">
            		<div class="col-md-12">
            			<div class="form-group">
            				<label class="control-label">Subject</label>
            				<select class="form-control">
            					<option value="Emergency">Emergency</option>
            					<option value="Enquiry">Enquiry</option>
            					<option value="Violation">Report a Violation</option>
            				</select>
            			</div>
            			<div class="form-group">
            				<label class="control-label">Message</label>
            				<textarea class="form-control" rows="10"></textarea>
            			</div>
            			<div class="form-group">
            				<label class="control-label">Attach File</label>
            				<input type="file" name="userfile">
            			</div>
            			<div class="form-group">
            				<input type="submit" name="submit" value="Send Message" class="btn theme-blue white">
            			</div>
            		</div>
            	</div>
            </div>
          </div>
        </div>
   	 	</div>
		</div>
	</div>
</div>