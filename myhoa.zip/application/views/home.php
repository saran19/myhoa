<div class="bg-home">	
		<div class="text-center col-md-12 pad-top-20">
      <br><br><br><br><br><br>
      <img src="<?=base_url();?>assets/images/logo1.png">
      
    </div>
</div>
