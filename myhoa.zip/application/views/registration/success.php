<br><br><div class="container pad-top-20"><br>
	<div class="row">
		<div class="col-md-12">
			<div id="rootwizard">
				<div class="navbar">
					<div class="navbar-inner">					
							<h3><strong>Success!</strong></h3>
					</div>
				</div>
				
					<div class="tab-content">
						<div class="tab-pane active" id="tab1">
							<div class="progress">
								<div class="progress-bar" role="progressbar" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100" style="width: 100%;">
										<strong>100%</strong>
								</div>
							</div>
							<p>Registration Success. Please activate your account which email has been sent.</p>
							<br>
							<a href="<?=base_url();?>" class="btn theme-blue white">Back to Home</a>
						</div>
					</div>
			</div>
		</div>
	</div>
</div>

